import subprocess

# List files in the current directory
print("Listing files in the current directory:")
subprocess.run(["ls"])  # Basic listing
subprocess.run(["ls", "-l"])  # Detailed listing
subprocess.run(["ls", "-l", "README.md"])  # Detailed info for README.md

# Gather system information
command = "uname"
commandArgument = "-a"
print(f'\nGathering system information with command: {command} {commandArgument}')
result = subprocess.run([command, commandArgument], capture_output=True, text=True)
print(result.stdout)  # Print the system information

# Gather active process information
command = "ps"
commandArgument = "-x"
print(f'\nGathering active process information with command: {command} {commandArgument}')
result = subprocess.run([command, commandArgument], capture_output=True, text=True)
print(result.stdout)  # Print the list of active processes
