import os
os.system("ls")
import subprocess
subprocess.run(["ls"])
subprocess.run(["ls","-l"])
