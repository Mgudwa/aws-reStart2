def is_prime(n):
    """Check if a number is prime."""
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

def write_primes_to_file(start, end, filename):
    """Write prime numbers between 'start' and 'end' to 'filename'."""
    primes = [str(num) for num in range(start, end + 1) if is_prime(num)]
    
    with open(filename, 'w') as f:
        f.write("\n".join(primes))

# Define the range and file path
start = 1
end = 250
file_path = 'results.txt'

# Write prime numbers to the file
write_primes_to_file(start, end, file_path)

# Print confirmation message
print(f"Prime numbers between {start} and {end} have been written to {file_path}.")
